#pragma once

#define ID_BUTTON 10
#define ID_MESSAGE 11